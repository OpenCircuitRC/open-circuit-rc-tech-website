KILL PASTEBOARD
===============

Purpose
-------
This utility fixes QuarkXPress documents that refuse to open in QuarkXPress 4
for Windows because the document says that the "Pasteboard XT" QuarkXPress
XTension is required.

What it does
------------
It looks for the byte sequence:

    XQRQXTPB

and changes only the first four bytes:

    XQRQ  ->  XXXX

This is the change that was successfully tested on the supplied Mac-created
Quark document. The rest of the document is left unchanged.

Safety
------
The original file is NEVER overwritten.

The program creates:

    original-name_No_Pasteboard_XT.qxd

If that name already exists, it creates a numbered copy instead.

If no XQRQ/XTPB marker is found, the file is not changed.

Windows app
-----------
The included KillPasteboard.py can be run with Python 3.

The included KillPasteboard.bat launches it.

For a standalone EXE, use PyInstaller:

    pyinstaller --onefile --windowed --name KillPasteboard KillPasteboard.py

Then use the EXE in the dist folder.

IMPORTANT
---------
This is a purpose-built fixer based on the successful binary test performed
against the supplied QuarkXPress document. Keep backups of important original
documents and test the fixed copy before relying on it for archival work.
