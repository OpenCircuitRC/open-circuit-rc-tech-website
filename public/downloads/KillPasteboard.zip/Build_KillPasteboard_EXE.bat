@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo       Kill Pasteboard - EXE Builder
echo ============================================
echo.
echo This will install/update PyInstaller if needed,
echo then create a standalone Windows EXE.
echo.

where py >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON=py -3"
    goto :python_found
)

where python >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON=python"
    goto :python_found
)

echo Python could not be found.
echo Please make sure Python is installed and try again.
echo.
pause
exit /b 1

:python_found
echo Installing/updating PyInstaller...
%PYTHON% -m pip install --upgrade pyinstaller
if errorlevel 1 (
    echo.
    echo PyInstaller installation failed.
    echo.
    pause
    exit /b 1
)

echo.
echo Building KillPasteboard.exe...
%PYTHON% -m PyInstaller --onefile --windowed --clean --name KillPasteboard KillPasteboard.py
if errorlevel 1 (
    echo.
    echo EXE build failed.
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================
echo BUILD COMPLETE
echo ============================================
echo.
echo Your standalone EXE is here:
echo.
echo %~dp0dist\KillPasteboard.exe
echo.
echo You can copy that EXE anywhere and run it
echo without Python or a command window.
echo.
pause
