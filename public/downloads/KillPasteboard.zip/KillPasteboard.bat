@echo off
setlocal
cd /d "%~dp0"

REM Try the Windows Python launcher first.
where py >nul 2>&1
if %errorlevel%==0 (
    py -3 "%~dp0KillPasteboard.py"
    goto :end
)

REM Try python.exe if the launcher is not installed.
where python >nul 2>&1
if %errorlevel%==0 (
    python "%~dp0KillPasteboard.py"
    goto :end
)

echo.
echo Python was not found.
echo.
echo If Python is installed, Windows may have the Microsoft Store
echo "python" execution alias enabled instead of the real Python.
echo.
echo You can disable it at:
echo Settings ^> Apps ^> Advanced app settings ^> App execution aliases
echo.
pause

:end
