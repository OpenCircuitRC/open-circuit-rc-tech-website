import os
import sys
import shutil
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

MAGIC = b"XQRQXTPB"

def fixed_name(path):
    root, ext = os.path.splitext(path)
    return root + "_No_Pasteboard_XT" + ext

def fix_file(path):
    try:
        with open(path, "rb") as f:
            data = bytearray(f.read())
    except Exception as e:
        return False, 0, f"Could not read file: {e}"

    positions = []
    start = 0
    while True:
        p = data.find(MAGIC, start)
        if p < 0:
            break
        positions.append(p)
        start = p + 1

    if not positions:
        return False, 0, "No XQRQ/XTPB Pasteboard requirement found."

    # Only neutralize the requirement marker. Do not alter any other bytes.
    for p in positions:
        data[p:p+4] = b"XXXX"

    out = fixed_name(path)
    if os.path.exists(out):
        n = 2
        while True:
            candidate = os.path.splitext(path)[0] + f"_No_Pasteboard_XT_{n}" + os.path.splitext(path)[1]
            if not os.path.exists(candidate):
                out = candidate
                break
            n += 1

    try:
        with open(out, "wb") as f:
            f.write(data)
    except Exception as e:
        return False, len(positions), f"Could not write output: {e}"

    return True, len(positions), out

def choose_files():
    paths = filedialog.askopenfilenames(
        title="Select QuarkXPress documents",
        filetypes=[
            ("QuarkXPress documents", "*.qxd"),
            ("All files", "*.*")
        ]
    )
    if paths:
        process(paths)

def process(paths):
    results = []
    success = 0
    for path in paths:
        ok, count, info = fix_file(path)
        if ok:
            success += 1
            results.append(f"✓ {os.path.basename(path)}  →  {os.path.basename(info)}  ({count} requirement marker(s) neutralized)")
        else:
            results.append(f"• {os.path.basename(path)}  →  {info}")

    log.delete("1.0", tk.END)
    log.insert(tk.END, "\n".join(results))
    status.set(f"Finished: {success} of {len(paths)} document(s) fixed.")

def show_about():
    messagebox.showinfo(
        "Kill Pasteboard",
        "Kill Pasteboard for QuarkXPress 4 Windows\n\n"
        "This utility makes a copy of a QuarkXPress document and "
        "neutralizes the XQRQ/XTPB Pasteboard XT requirement marker.\n\n"
        "The original document is never overwritten."
    )

root = tk.Tk()
root.title("Kill Pasteboard")
root.geometry("760x470")
root.minsize(650, 400)

style = ttk.Style()
try:
    style.theme_use("vista")
except Exception:
    pass

frame = ttk.Frame(root, padding=18)
frame.pack(fill="both", expand=True)

ttk.Label(frame, text="Kill Pasteboard", font=("Segoe UI", 20, "bold")).pack(anchor="w")
ttk.Label(
    frame,
    text="Remove the old Pasteboard XT requirement from QuarkXPress documents",
    font=("Segoe UI", 10)
).pack(anchor="w", pady=(2, 16))

ttk.Button(frame, text="Select Quark Documents…", command=choose_files).pack(anchor="w")

ttk.Label(
    frame,
    text="\nThe fixer creates a new copy named *_No_Pasteboard_XT.qxd.\n"
         "Your original files are never modified.",
    justify="left"
).pack(anchor="w", pady=(10, 8))

log = tk.Text(frame, height=15, wrap="word", font=("Consolas", 9))
log.pack(fill="both", expand=True)

bottom = ttk.Frame(frame)
bottom.pack(fill="x", pady=(10, 0))
status = tk.StringVar(value="Ready.")
ttk.Label(bottom, textvariable=status).pack(side="left")
ttk.Button(bottom, text="About", command=show_about).pack(side="right")

root.mainloop()
